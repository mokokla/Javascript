function startGame(){
    document.getElementById("font").style.color = "red";
    window.location = "game.html";
}

function openSettings(){
    document.getElementById("font").style.color = "red";
    window.location = "settings.html";
}